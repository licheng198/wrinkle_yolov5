# -*- coding:utf-8 -*-

"""
# @Time       : 2022/1/20 22:47
# @Author     : GraceKafuu
# @Email      :
# @File       : inference.py
# @Software   : PyCharm

Description:
"""
import numpy
import pyrealsense2 as rs
import numpy as np
import cv2
import torch
import time
import rtde_control
import rtde_io
import rtde_receive
import copy
import operator

# model = torch.hub.load('ultralytics/yolov5', 'custom', path='./runs/train/exp5/weights/best.pt')
model = torch.hub.load('C:/Users/46005/.cache/torch/hub/ultralytics_yolov5_master', 'custom',
                       path='./runs/train/exp5/weights/best.pt', source='local')  # local repo
# model.conf = 0.5

def dectshow(org_img, boxs):
    img = org_img.copy()
    for box in boxs:
        cv2.rectangle(img, (int(box[0]), int(box[1])), (int(box[2]), int(box[3])), (0, 255, 0), 2)
        cv2.putText(img, box[-1], (int(box[0]), int(box[1])), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.circle(img, (int(box[0]), int(box[1])), 3, (0, 0, 255), -1)
        cv2.circle(img, (int(box[2]), int(box[3])), 3, (0, 0, 255), -1)
        cv2.circle(img, (int(box[0]), int(box[3])), 3, (0, 0, 255), -1)
        cv2.circle(img, (int(box[2]), int(box[1])), 3, (0, 0, 255), -1)
    cv2.imshow('dec_img', img)

def cam2world(u, v):
    pix = np.mat([[u],
                  [v],
                  [1]])

    # 相机内参
    f = np.mat([[922.035165318330, 0, 637.334189521105],
               [0, 923.082990800469, 367.480260280167],
               [0, 0, 1]])


    # #相机内参
    # f = np.mat([[909.759592140384, 0, 637.379450662504],
    #             [0, 909.878575049015, 369.287333921517],
    #             [0, 0, 1.000]])

    # 相机外参
    K = np.mat([[0.9998, 0.0201, -0.0084, -411.6200],
                [0.0201, -0.9998, -0.0074, -433.5865],
                [-0.0085, 0.0072, -0.9999, 985.1374],
                [0, 0, 0, 1]])

    # 相机外参
    # K = np.mat([[0.9997, 0.0027, 0.0242, -258.9438],
    #             [0.0027, -1.0000, -0.0002, -430.1141],
    #             [0.0242, 0.0003, -0.9997, 578.5774],
    #             [0, 0, 0, 1.000000]])
    # 相机到平面距离
    Z = 985.1374
    pix2cam = f.I * pix * Z
    pix2cam = np.row_stack((pix2cam, [1]))
    world = K * pix2cam

    return float(world[0][0]) / 1000, float(world[1][0]) / 1000

if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    pipeline = rs.pipeline()
    config = rs.config()
    print("success real")
    # Get device product line for setting a supporting resolution
    pipeline_wrapper = rs.pipeline_wrapper(pipeline)
    pipeline_profile = config.resolve(pipeline_wrapper)
    device = pipeline_profile.get_device()
    device_product_line = str(device.get_info(rs.camera_info.product_line))

    found_rgb = False
    for s in device.sensors:
        if s.get_info(rs.camera_info.name) == 'RGB Camera':
            found_rgb = True
            break
    if not found_rgb:
        print("The demo requires Depth camera with Color sensor")
        exit(0)

    config.enable_stream(rs.stream.color, 1280, 720, rs.format.bgr8, 30)

    # Start streaming
    pipeline.start(config)
    print("success start")

    # 连接机械臂
    rtde_c = rtde_control.RTDEControlInterface("192.168.1.2")
    rtde_io_ = rtde_io.RTDEIOInterface("192.168.1.2")
    rtde_receive_ = rtde_receive.RTDEReceiveInterface("192.168.1.2")
    start_pose = [-0.12141970835506544, -0.19883396058300074, 0.32796442284431773, -2.1669682982724088, -2.2723446449242855, 0.0030847133334053717]

    rtde_c.moveL(start_pose, 0.1, 0.1)

    left_top_flag = False
    right_top_flag = False
    left_bottom_flag = False
    right_bottom_flag = False

    left_top_reach = False
    right_top_reach = False
    left_bottom_reach = False
    right_bottom_reach = False
    try:
        while True:

            # Wait for a coherent pair of frames: depth and color
            print("wait frame")
            frames = pipeline.wait_for_frames()
            color_frame = frames.get_color_frame()
            if not color_frame:
                continue

            # Convert images to numpy arrays
            color_image = np.asanyarray(color_frame.get_data())

            print("start detect")
            results = model(color_image)
            boxs = results.pandas().xyxy[0].values
            dectshow(color_image, boxs)
            print("finish detect")

            # count是计数褶皱数目
            count = 0
            # 计数角点数目
            count1 = 0
            count2 = 0
            count3 = 0
            count4 = 0
            i = 0
            areas = [0] * 10
            max_wrinkle_pos = numpy.zeros((10, 2))
            # 机械臂到达布料左上角
            for box in boxs:
                if box[-1] == 'left_top':
                    count1 = count1 + 1
                    u1 = box[2]
                    v1 = box[3]
                    x1, y1 = cam2world(u1, v1)
                    print('left_top: %f,%f' % (u1, v1))
                elif box[-1] == 'right_top':
                    count2 = count2 + 1
                    u2 = box[0]
                    v2 = box[3]
                    x2, y2 = cam2world(u2, v2)
                    print('right_top: %f,%f' % (u2, v2))
                elif box[-1] == 'left_bottom':
                    count3 = count3 + 1
                    u3 = box[2]
                    v3 = box[1]
                    x3, y3 = cam2world(u3, v3)
                    print('left_bottom: %f,%f' % (u3, v3))
                elif box[-1] == 'right_bottom':
                    count4 = count4 + 1
                    u4 = box[0]
                    v4 = box[1]
                    x4, y4 = cam2world(u4, v4)
                    print('right_bottom: %f,%f' % (u4, v4))
                elif box[-1] == 'lt_rb_wrinkle' or 'lb_rt_wrinkle':
                    count = count + 1
                    width = box[2] - box[0]
                    height = box[3] - box[1]
                    u = (box[0] + box[2])/2
                    v = (box[1] + box[3])/2
                    areas[i] = width * height
                    max_wrinkle_pos[i][0] = u
                    max_wrinkle_pos[i][1] = v
                    i = i + 1
                    # print(image.shape)
            max_index, max_number = max(enumerate(areas), key=operator.itemgetter(1))
            print('wrinkle%d: %f,%f' % (count, max_wrinkle_pos[max_number][0], max_wrinkle_pos[max_number][1]))
            distance = 0.03
            if count != 0 and count1 == 1 and count2 == 1 and count3 == 1 and count4 == 1:
                # 左上对右下的斜率
                k1 = abs((y4 - y1) / (x4 - x1))
                # 左下对右上的斜率
                k2 = abs((y3 - y2) / (x3 - x2))

                # 机械臂操作左上角
                if left_top_reach is False:
                    left_top_up_pose = copy.deepcopy(start_pose)
                    left_top_up_pose[0] = x1
                    left_top_up_pose[1] = y1
                    left_top_up_pose[2] = left_top_up_pose[2] - 0.1
                    rtde_c.moveL(left_top_up_pose, 0.1, 0.1)

                    # 数字输出0为高电平时，夹爪张开
                    rtde_io_.setStandardDigitalOut(0, True)

                    # 机械臂下降
                    left_top_down_pose = copy.deepcopy(left_top_up_pose)
                    left_top_down_pose[2] = left_top_down_pose[2] - 0.028
                    rtde_c.moveL(left_top_down_pose, 0.1, 0.1)

                    # 夹爪闭合
                    rtde_io_.setStandardDigitalOut(1, True)

                    # 机械臂向左上角移动
                    left_top_targ_pose = copy.deepcopy(left_top_up_pose)
                    left_top_targ_pose[0] = left_top_targ_pose[0] - distance
                    left_top_targ_pose[1] = left_top_targ_pose[1] + distance * k2
                    rtde_c.moveL(left_top_targ_pose, 0.1, 0.1)

                    # 夹爪松弛
                    rtde_io_.setStandardDigitalOut(1, False)
                    time.sleep(0.1)
                    rtde_io_.setStandardDigitalOut(0, False)

                    # 回到初始位置
                    rtde_c.moveL(start_pose, 0.1, 0.1)

                    left_top_reach = True
                    # continue跳出本次循环，即重新开始检测，但是left_top_reach等变量是在循环外定义的，保留上次循环的更改
                    continue

                # 机械臂操作右上角
                if left_top_reach is True and right_top_reach is False:
                    right_top_up_pose = copy.deepcopy(start_pose)
                    right_top_up_pose[0] = x2
                    right_top_up_pose[1] = y2
                    right_top_up_pose[2] = right_top_up_pose[2] - 0.1
                    rtde_c.moveL(right_top_up_pose, 0.1, 0.1)

                    # 数字输出0为高电平时，夹爪张开
                    rtde_io_.setStandardDigitalOut(0, True)

                    # 机械臂下降
                    right_top_down_pose = copy.deepcopy(right_top_up_pose)
                    right_top_down_pose[2] = right_top_down_pose[2] - 0.028
                    rtde_c.moveL(right_top_down_pose, 0.1, 0.1)

                    # 夹爪闭合
                    rtde_io_.setStandardDigitalOut(1, True)

                    # 机械臂向右上角移动
                    right_top_targ_pose = copy.deepcopy(right_top_up_pose)
                    right_top_targ_pose[0] = right_top_targ_pose[0] + distance
                    right_top_targ_pose[1] = right_top_targ_pose[1] + distance * k1
                    rtde_c.moveL(right_top_targ_pose, 0.1, 0.1)
                    rtde_io_.setStandardDigitalOut(1, False)
                    time.sleep(0.1)
                    rtde_io_.setStandardDigitalOut(0, False)

                    # 回到初始位置
                    rtde_c.moveL(start_pose, 0.1, 0.1)

                    right_top_reach = True
                    continue

                    # 机械臂操作左下角
                if left_bottom_reach is False and left_top_reach is True and right_top_reach is True:
                    left_bottom_up_pose = copy.deepcopy(start_pose)
                    left_bottom_up_pose[0] = x3
                    left_bottom_up_pose[1] = y3
                    left_bottom_up_pose[2] = left_bottom_up_pose[2] - 0.1
                    rtde_c.moveL(left_bottom_up_pose, 0.1, 0.1)

                    # 数字输出0为高电平时，夹爪张开
                    rtde_io_.setStandardDigitalOut(0, True)

                    # 机械臂下降
                    left_bottom_down_pose = copy.deepcopy(left_bottom_up_pose)
                    left_bottom_down_pose[2] = left_bottom_down_pose[2] - 0.028
                    rtde_c.moveL(left_bottom_down_pose, 0.1, 0.1)

                    # 夹爪闭合
                    rtde_io_.setStandardDigitalOut(1, True)

                    # 机械臂向左下角移动
                    left_bottom_targ_pose = copy.deepcopy(left_bottom_up_pose)
                    left_bottom_targ_pose[0] = left_bottom_targ_pose[0] - distance
                    left_bottom_targ_pose[1] = left_bottom_targ_pose[1] - distance * k1
                    rtde_c.moveL(left_bottom_targ_pose, 0.1, 0.1)
                    rtde_io_.setStandardDigitalOut(1, False)
                    time.sleep(0.1)
                    rtde_io_.setStandardDigitalOut(0, False)

                    # 回到初始位置
                    rtde_c.moveL(start_pose, 0.1, 0.1)

                    left_bottom_reach = True
                    continue
                if left_bottom_reach is True and left_top_reach is True and right_top_reach is True and right_bottom_reach is False:
                    right_bottom_up_pose = copy.deepcopy(start_pose)
                    right_bottom_up_pose[0] = x4
                    right_bottom_up_pose[1] = y4
                    right_bottom_up_pose[2] = right_bottom_up_pose[2] - 0.1
                    rtde_c.moveL(right_bottom_up_pose, 0.1, 0.1)

                    # 数字输出0为高电平时，夹爪张开
                    rtde_io_.setStandardDigitalOut(0, True)

                    # 机械臂下降
                    right_bottom_down_pose = copy.deepcopy(right_bottom_up_pose)
                    right_bottom_down_pose[2] = right_bottom_down_pose[2] - 0.028
                    rtde_c.moveL(right_bottom_down_pose, 0.1, 0.1)

                    # 夹爪闭合
                    rtde_io_.setStandardDigitalOut(1, True)

                    # 机械臂向左下角移动
                    right_bottom_targ_pose = copy.deepcopy(right_bottom_up_pose)
                    right_bottom_targ_pose[0] = right_bottom_targ_pose[0] + distance
                    right_bottom_targ_pose[1] = right_bottom_targ_pose[1] - distance * k2
                    rtde_c.moveL(right_bottom_targ_pose, 0.1, 0.1)
                    rtde_io_.setStandardDigitalOut(1, False)
                    time.sleep(0.1)
                    rtde_io_.setStandardDigitalOut(0, False)

                    # 回到初始位置
                    rtde_c.moveL(start_pose, 0.1, 0.1)

                    left_top_reach = False
                    right_top_reach = False
                    left_bottom_reach = False
                    right_bottom_reach = False
                    continue
            elif count == 0:
                break
    finally:

        # Stop streaming
        pipeline.stop()